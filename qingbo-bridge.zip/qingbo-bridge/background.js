const ALLOW = ['https://ai-gateway.insta360.cn/'];
chrome.runtime.onMessage.addListener((msg, sender, send) => {
  if (!msg || msg.type !== 'QB_FETCH') return;
  const fromOk = (sender.url || '').startsWith('https://ziheng-work.github.io/qingbo-helper/');
  if (!fromOk || !ALLOW.some(a => String(msg.url).startsWith(a))) { send({ ok: false, status: 0, text: '桥接扩展只允许访问公司 AI 网关' }); return; }
  fetch(msg.url, { method: msg.method || 'GET', headers: msg.headers || {}, body: msg.body })
    .then(async r => send({ ok: r.ok, status: r.status, text: await r.text() }))
    .catch(e => send({ ok: false, status: 0, text: String(e && e.message || e) }));
  return true;
});

// 表单页取清博帖子截图（飞书附件临时链接），转成 dataURL 交给表单页
chrome.runtime.onMessage.addListener((msg, sender, send) => {
  if (!msg || msg.type !== 'QB_FETCH_BIN') return;
  const fromOk = /^https:\/\/[a-z0-9-]+\.feishu\.cn\/share\/base\/form\//.test(sender.url || '');
  let host = ''; try { host = new URL(msg.url).hostname; } catch (e) {}
  if (!fromOk || !/(^|\.)(feishu\.cn|feishucdn\.com|larkoffice\.com)$/.test(host)) { send({ ok: false, text: '只允许取飞书附件' }); return; }
  fetch(msg.url, { credentials: 'include' })
    .then(async r => {
      if (!r.ok) { send({ ok: false, text: 'HTTP ' + r.status }); return; }
      const blob = await r.blob();
      const buf = new Uint8Array(await blob.arrayBuffer());
      let s = ''; for (let i = 0; i < buf.length; i += 0x8000) s += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
      send({ ok: true, type: blob.type || 'image/png', b64: btoa(s) });
    })
    .catch(e => send({ ok: false, text: String(e && e.message || e) }));
  return true;
});

// 批量录单：录单助手让扩展在后台标签页打开一张预填表单（form.js 自动填好并提交），结果再转回录单助手
chrome.runtime.onMessage.addListener((msg, sender, send) => {
  if (!msg) return;
  if (msg.type === 'QB_OPEN') {
    const fromOk = (sender.url || '').startsWith('https://ziheng-work.github.io/qingbo-helper/');
    const urlOk = /^https:\/\/[a-z0-9-]+\.feishu\.cn\/share\/base\/form\//.test(String(msg.url));
    if (!fromOk || !urlOk || !sender.tab) { send({ ok: false, text: '只能打开飞书录单表单' }); return; }
    const url = msg.url + (msg.url.includes('#') ? '&' : '#') + 'qb_src=' + sender.tab.id + '.' + (sender.frameId || 0);
    chrome.tabs.create({ url, active: false, index: sender.tab.index + 1 }, t => send({ ok: !!t, tabId: t && t.id, text: chrome.runtime.lastError ? chrome.runtime.lastError.message : '' }));
    return true;
  }
  if (msg.type === 'QB_FORM_DONE') {
    const fromOk = /^https:\/\/[a-z0-9-]+\.feishu\.cn\/share\/base\/form\//.test(sender.url || '');
    const m = /^(\d+)\.(\d+)$/.exec(String(msg.src || ''));
    if (!fromOk || !m) return;
    chrome.tabs.sendMessage(+m[1], { type: 'QB_FORM_RES', id: msg.id, ok: !!msg.ok, text: String(msg.text || '') }, { frameId: +m[2] }, () => void chrome.runtime.lastError);
    if (msg.ok && sender.tab) setTimeout(() => chrome.tabs.remove(sender.tab.id, () => void chrome.runtime.lastError), 1500);
  }
});
