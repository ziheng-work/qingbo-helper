const ALLOW = ['https://ai-gateway.insta360.cn/'];
chrome.runtime.onMessage.addListener((msg, sender, send) => {
  if (!msg || msg.type !== 'QB_FETCH') return;
  const fromOk = (sender.url || '').startsWith('https://ziheng-work.github.io/qingbo-helper/');
  if (!fromOk || !ALLOW.some(a => String(msg.url).startsWith(a))) { send({ ok: false, status: 0, text: '桥接扩展只允许访问公司 AI 网关' }); return; }
  fetch(msg.url, { method: msg.method || 'GET', headers: msg.headers || {}, body: msg.body })
    .then(async r => send({ ok: r.ok, status: r.status, text: await r.text() }))
    .catch(e => send({ ok: false, status: 0, text: String(e && e.message || e) }));
  return true;
});
