// 录单助手桥接：在「每日社媒处理录入表」表单页自动选上产品型号、放上清博帖子截图。
// 只在地址带 #qb_models= / qb_shot= 时动作（由录单助手的「打开预填表单」带过来）；平时只选型号、放截图；只有批量录单（带 qb_auto=1）时才替你点提交。
(() => {
  const hv = k => { const m = new RegExp('[#&]' + k + '=([^&]*)').exec(location.hash || ''); if (!m) return []; try { return decodeURIComponent(m[1]).split('|').map(s => s.trim()).filter(Boolean); } catch (e) { return []; } };
  const models = hv('qb_models'), shots = hv('qb_shot');
  if (!models.length && !shots.length && hv('qb_auto')[0] !== '1') return;

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const fire = (el, t) => el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window }));
  const click = el => ['mousedown', 'mouseup', 'click'].forEach(t => fire(el, t));
  const setVal = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
  const shown = e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  const boxes = () => [...document.querySelectorAll('input[placeholder="查找选项"]')].filter(shown);

  function tip(text, ok) {
    let el = document.getElementById('qb-tip');
    if (!el) {
      el = document.createElement('div'); el.id = 'qb-tip';
      el.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:99999;max-width:320px;padding:10px 14px;border-radius:8px;font:14px/1.5 -apple-system,"PingFang SC",sans-serif;color:#fff;box-shadow:0 4px 16px rgba(0,0,0,.25)';
      document.body.appendChild(el);
    }
    el.style.background = ok ? '#2ea121' : '#e8321e';
    el.textContent = text;
    clearTimeout(el._h); el._h = setTimeout(() => el.remove(), ok ? 6000 : 15000);
  }

  async function findField() {
    for (let i = 0; i < 60; i++) {
      const lab = [...document.querySelectorAll('label')].find(l => l.innerText.includes('产品型号'));
      if (lab) {
        let box = lab;
        while (box && !box.querySelector('.b-select-dropdown-menu')) box = box.parentElement;
        if (box) return box;
      }
      await sleep(500);
    }
    return null;
  }

  async function pickModels() {
    if (!models.length) return { ok: true, text: '' };
    const box = await findField();
    if (!box) return { ok: false, text: '没找到「产品型号」这一项，请手动选：' + models.join('、') };
    await sleep(800);
    const trig = box.querySelector('.b-select-dropdown-menu');
    const base = boxes().length; // 页面上其他下拉框自带的搜索框，不算
    const openBox = async () => {
      if (boxes().length <= base) { trig.scrollIntoView({ block: 'center' }); await sleep(300); click(trig); await sleep(800); }
      const a = boxes(); return a.length > base ? a[a.length - 1] : null;
    };
    const done = [], miss = [];
    for (const name of models) {
      if ([...box.querySelectorAll('.ud__tag__content')].some(t => !t.closest('li') && t.innerText.trim() === name)) { done.push(name); continue; }
      const inp = await openBox();
      if (!inp) { miss.push(name); continue; }
      inp.focus(); setVal.call(inp, name); inp.dispatchEvent(new Event('input', { bubbles: true }));
      await sleep(900);
      const li = [...document.querySelectorAll('li.b-select-option')].filter(shown).find(e => e.innerText.trim() === name);
      if (!li) { miss.push(name); continue; }
      click(li); await sleep(500); done.push(name);
    }
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    fire(document.body, 'mousedown'); fire(document.body, 'mouseup'); fire(document.body, 'click');
    if (miss.length) return { ok: false, text: '型号已选 ' + (done.join('、') || '无') + '；表单里没有「' + miss.join('、') + '」这个选项，请手动选' };
    return { ok: true, text: '已选型号 ' + done.join('、') };
  }

  const getBin = url => new Promise(res => {
    try { chrome.runtime.sendMessage({ type: 'QB_FETCH_BIN', url }, r => res(r || { ok: false, text: chrome.runtime.lastError && chrome.runtime.lastError.message })); }
    catch (e) { res({ ok: false, text: String(e) }); }
  });

  async function putShots() {
    if (!shots.length) return { ok: false, text: '清博没有截图，请自己截图上传' };
    let inp = null;
    for (let i = 0; i < 40 && !inp; i++) {
      const ls = [...document.querySelectorAll('label')]; const lab = ls.find(l => l.innerText.includes('原帖截图')) || ls.find(l => l.innerText.includes('截图'));
      let el = lab; while (el && !el.querySelector('input[type=file]')) el = el.parentElement;
      inp = el ? el.querySelector('input[type=file]') : null;
      if (!inp) await sleep(500);
    }
    if (!inp) return { ok: false, text: '没找到「原帖截图」上传框，请手动上传' };
    const dt = new DataTransfer(); let bad = 0;
    for (let i = 0; i < shots.length; i++) {
      const r = await getBin(shots[i]);
      if (!r || !r.ok) { bad++; continue; }
      const bin = atob(r.b64), u = new Uint8Array(bin.length);
      for (let j = 0; j < bin.length; j++) u[j] = bin.charCodeAt(j);
      const ext = (r.type.split('/')[1] || 'png').replace('jpeg', 'jpg');
      dt.items.add(new File([u], '清博截图' + (i + 1) + '.' + ext, { type: r.type }));
    }
    if (!dt.files.length) return { ok: false, text: '清博截图取不下来（链接可能过期），请回插件重新点「打开预填表单」，或手动上传' };
    inp.files = dt.files;
    inp.dispatchEvent(new Event('change', { bubbles: true }));
    return { ok: !bad, text: '已放上清博截图 ' + dt.files.length + ' 张' + (bad ? '（' + bad + ' 张没取到）' : '') };
  }

  const auto = hv('qb_auto')[0] === '1', qid = hv('qb_id')[0] || '', src = hv('qb_src')[0] || '';
  const report = (ok, text) => { try { chrome.runtime.sendMessage({ type: 'QB_FORM_DONE', id: qid, src, ok, text }); } catch (e) {} };
  const formGone = () => ![...document.querySelectorAll('label')].some(l => l.innerText.includes('产品型号'));
  const subBtn = () => [...document.querySelectorAll('button')].filter(shown).find(b => /^(提交|Submit)$/i.test(b.innerText.trim()));

  async function submit() {
    // 等截图传完：文件名出现后再多等几秒
    if (shots.length) { for (let i = 0; i < 40 && !document.body.innerText.includes('清博截图1'); i++) await sleep(500); await sleep(4000); }
    const btn = subBtn();
    if (!btn) return { ok: false, text: '没找到「提交」按钮' };
    btn.scrollIntoView({ block: 'center' }); await sleep(300); btn.click();
    for (let i = 0; i < 60; i++) {
      await sleep(500);
      if (formGone() || /提交成功|已提交|Submitted/.test(document.body.innerText.slice(0, 2000)) && !subBtn()) return { ok: true, text: '已提交' };
    }
    return { ok: false, text: '表单没提交成功，可能有必填项没填（去那个标签页看红字）' };
  }

  (async () => {
    const a = await pickModels();
    const b = await putShots();
    try { history.replaceState(null, '', location.pathname + location.search); } catch (e) {}
    if (!auto) {
      const ok = a.ok && b.ok;
      tip('录单助手：' + [a.text, b.text].filter(Boolean).join('；') + (ok ? '。检查一下就可以提交' : ''), ok);
      return;
    }
    // 批量模式：型号没选上、或清博有截图却没放上，就不提交，留着这个标签页给人处理
    if (!a.ok || (shots.length && !b.ok)) { const t = [a.text, b.text].filter(Boolean).join('；'); tip('录单助手（批量）：没提交。' + t, false); report(false, t); return; }
    tip('录单助手（批量）：已填好，正在提交…', true);
    const r = await submit();
    tip('录单助手（批量）：' + r.text, r.ok);
    report(r.ok, r.text + (shots.length ? '' : '（无截图）'));
  })();
})();
