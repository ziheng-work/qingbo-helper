// 录单助手桥接：在「每日社媒处理录入表」表单页自动选上产品型号。
// 只在地址带 #qb_models=... 时动作（由录单助手的「打开预填表单」带过来）；只选型号，不提交表单。
(() => {
  const m = /[#&]qb_models=([^&]*)/.exec(location.hash || '');
  if (!m) return;
  let models = [];
  try { models = decodeURIComponent(m[1]).split('|').map(s => s.trim()).filter(Boolean); } catch (e) { return; }
  if (!models.length) return;

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const fire = (el, t) => el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window }));
  const click = el => ['mousedown', 'mouseup', 'click'].forEach(t => fire(el, t));
  const setVal = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
  const shown = e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  const boxes = () => [...document.querySelectorAll('input[placeholder="查找选项"]')].filter(shown);

  function tip(text, ok) {
    let el = document.getElementById('qb-tip');
    if (!el) {
      el = document.createElement('div'); el.id = 'qb-tip';
      el.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:99999;max-width:320px;padding:10px 14px;border-radius:8px;font:14px/1.5 -apple-system,"PingFang SC",sans-serif;color:#fff;box-shadow:0 4px 16px rgba(0,0,0,.25)';
      document.body.appendChild(el);
    }
    el.style.background = ok ? '#2ea121' : '#e8321e';
    el.textContent = text;
    clearTimeout(el._h); el._h = setTimeout(() => el.remove(), ok ? 6000 : 15000);
  }

  async function findField() {
    for (let i = 0; i < 60; i++) {
      const lab = [...document.querySelectorAll('label')].find(l => l.innerText.includes('产品型号'));
      if (lab) {
        let box = lab;
        while (box && !box.querySelector('.b-select-dropdown-menu')) box = box.parentElement;
        if (box) return box;
      }
      await sleep(500);
    }
    return null;
  }

  async function run() {
    const box = await findField();
    if (!box) { tip('录单助手：没找到「产品型号」这一项，请手动选：' + models.join('、'), false); return; }
    await sleep(800);
    const trig = box.querySelector('.b-select-dropdown-menu');
    const base = boxes().length; // 页面上其他下拉框自带的搜索框，不算
    const openBox = async () => {
      if (boxes().length <= base) { trig.scrollIntoView({ block: 'center' }); await sleep(300); click(trig); await sleep(800); }
      const a = boxes(); return a.length > base ? a[a.length - 1] : null;
    };
    const done = [], miss = [];
    for (const name of models) {
      if ([...box.querySelectorAll('.ud__tag__content')].some(t => !t.closest('li') && t.innerText.trim() === name)) { done.push(name); continue; }
      const inp = await openBox();
      if (!inp) { miss.push(name); continue; }
      inp.focus(); setVal.call(inp, name); inp.dispatchEvent(new Event('input', { bubbles: true }));
      await sleep(900);
      const li = [...document.querySelectorAll('li.b-select-option')].filter(shown).find(e => e.innerText.trim() === name);
      if (!li) { miss.push(name); continue; }
      click(li); await sleep(500); done.push(name);
    }
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    fire(document.body, 'mousedown'); fire(document.body, 'mouseup'); fire(document.body, 'click');
    if (miss.length) tip('录单助手：已选 ' + (done.join('、') || '无') + '；表单里没有「' + miss.join('、') + '」这个选项，请手动选', false);
    else tip('录单助手：已自动选上产品型号 ' + done.join('、') + '。还差截图，检查后提交', true);
    try { history.replaceState(null, '', location.pathname + location.search); } catch (e) {}
  }
  run();
})();
