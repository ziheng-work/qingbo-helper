// 录单助手桥接：在社媒帖处理系统的工单详情里替你点流程节点（完成「待首回」、流转到「待关单」并完成）。
// 只有录单助手发起、由扩展后台打开的那个标签页才会动作；平时打开飞书页面什么都不做。
(async () => {
  if (window.top !== window) return;
  const ask = m => new Promise(r => { try { chrome.runtime.sendMessage(m, x => r(chrome.runtime.lastError ? null : x)); } catch (e) { r(null); } });
  const job = await ask({ type: 'QB_STAGE_JOB' });
  if (!job || !job.mode) return;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const shown = e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  const report = (ok, text) => ask({ type: 'QB_STAGE_DONE', id: job.id, src: job.src, ok, text });
  function tip(text, ok) {
    let el = document.getElementById('qb-tip');
    if (!el) { el = document.createElement('div'); el.id = 'qb-tip'; el.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:999999;max-width:340px;padding:10px 14px;border-radius:8px;font:14px/1.5 -apple-system,"PingFang SC",sans-serif;color:#fff;box-shadow:0 4px 16px rgba(0,0,0,.25)'; document.body.appendChild(el); }
    el.style.background = ok ? '#2ea121' : '#e8321e'; el.textContent = '录单助手：' + text;
  }
  const until = async (fn, ms) => { const t = Date.now(); while (Date.now() - t < ms) { const v = fn(); if (v) return v; await sleep(400); } return null; };
  const items = () => [...document.querySelectorAll('.bitable-stage-flow_item')].filter(shown);
  const nameOf = it => (it.innerText || '').trim();
  const inputOf = it => it.querySelector('.bitable-stage-flow_item_input') || it;
  const current = () => items().find(it => /progressing/.test(inputOf(it).className));
  const focusName = () => { const e = document.querySelector('.focus-stage-name'); return e ? e.innerText.trim() : ''; };
  const doneBtn = () => [...document.querySelectorAll('button')].filter(shown).find(b => b.innerText.trim() === '完成节点' && !b.disabled);
  const toastText = () => [...document.querySelectorAll('.ud__toast, .ud__message, .ud__notice, [class*="toast"]')].filter(shown).map(e => e.innerText.trim()).filter(Boolean).join('；').slice(0, 80);
  const confirmIfAsked = async () => { await sleep(600); const b = [...document.querySelectorAll('.ud__modal button, .ud__confirm button, [role=dialog] .ud__button--filled')].filter(shown).find(x => /^(确定|确认|完成|继续)$/.test(x.innerText.trim())); if (b) { b.click(); await sleep(600); } };
  const preview = async key => {
    const it = items().find(x => nameOf(x).includes(key)); if (!it) return false;
    (it.querySelector('.bitable-stage-flow_item_content') || it).click();
    return !!(await until(() => focusName().includes(key), 6000));
  };
  try {
    // 1. 等工单详情出来，切到流程页签
    const tab = await until(() => [...document.querySelectorAll('[role=tab], .ud__tabs__tab, div, span')].filter(shown).find(e => e.childElementCount <= 1 && /^社媒支持流程\/Status$/.test((e.innerText || '').trim())), 45000);
    if (!tab) throw new Error('没打开工单详情（没找到「社媒支持流程」页签）');
    tab.click();
    if (!(await until(() => items().length >= 2, 20000))) throw new Error('流程节点没加载出来');
    await sleep(800);
    const steps = [];
    let cur = current();
    if (!cur) throw new Error('这张单没有进行中的节点（可能已关单或流程已终止）');
    // 2. 待首回 → 完成节点
    if (nameOf(cur).includes('待首回')) {
      if (!(await preview('待首回'))) throw new Error('点不到「待首回」节点');
      const b = doneBtn(); if (!b) throw new Error('「待首回」没有可点的「完成节点」（可能你不在分配人员里）');
      b.click(); await confirmIfAsked();
      const moved = await until(() => { const c = current(); return !c || !nameOf(c).includes('待首回'); }, 15000);
      if (!moved) throw new Error('「待首回」没完成' + (toastText() ? '：' + toastText() : '，可能有必填项没填'));
      steps.push('首回');
    }
    // 3. 关单：流转到待关单 → 完成节点
    if (job.mode === 'close') {
      if (!(await preview('待关单'))) throw new Error('点不到「待关单」节点');
      await sleep(600);
      const b = doneBtn(); if (!b) throw new Error('「待关单」没有可点的「完成节点」');
      b.click(); await confirmIfAsked();
      const closed = await until(() => { const last = items().find(x => nameOf(x).includes('待关单')); if (!last) return false; const c = inputOf(last).className; return !/pendding|pending/.test(c) && !current(); }, 15000);
      if (!closed) throw new Error('「待关单」没完成' + (toastText() ? '：' + toastText() : '，可能「用户是否回复」或「关单原因」没填'));
      steps.push('关单');
    }
    const text = steps.length ? '节点已点：' + steps.join('、') : '节点不用动';
    tip(text, true); await report(true, text);
  } catch (e) {
    const text = (e && e.message) || String(e);
    tip('节点没点成：' + text + '。这个标签页留着，可以手动点。', false);
    await report(false, text);
  }
})();
