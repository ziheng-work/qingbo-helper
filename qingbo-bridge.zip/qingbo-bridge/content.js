(() => {
  const post = m => window.postMessage(m, location.origin);
  window.addEventListener('message', e => {
    if (e.source !== window || !e.data) return;
    const d = e.data;
    if (d.type === 'QB_BRIDGE_PING') post({ type: 'QB_BRIDGE_READY', version: '1.0.0' });
    if (d.type === 'QB_BRIDGE_REQ') {
      chrome.runtime.sendMessage({ type: 'QB_FETCH', url: d.url, method: d.method, headers: d.headers, body: d.body }, res => {
        post({ type: 'QB_BRIDGE_RES', id: d.id, res: res || { ok: false, status: 0, text: chrome.runtime.lastError ? chrome.runtime.lastError.message : '无响应' } });
      });
    }
  });
  post({ type: 'QB_BRIDGE_READY', version: '1.0.0' });
})();
