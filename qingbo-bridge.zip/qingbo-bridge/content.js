(() => {
  const post = m => window.postMessage(m, location.origin);
  window.addEventListener('message', e => {
    if (e.source !== window || !e.data) return;
    const d = e.data;
    if (d.type === 'QB_BRIDGE_PING') post({ type: 'QB_BRIDGE_READY', version: '1.4.0' });
    if (d.type === 'QB_BRIDGE_REQ') {
      chrome.runtime.sendMessage({ type: 'QB_FETCH', url: d.url, method: d.method, headers: d.headers, body: d.body }, res => {
        post({ type: 'QB_BRIDGE_RES', id: d.id, res: res || { ok: false, status: 0, text: chrome.runtime.lastError ? chrome.runtime.lastError.message : '无响应' } });
      });
    }
  });
  window.addEventListener('message', e => {
    if (e.source !== window || !e.data || e.data.type !== 'QB_OPEN_REQ') return;
    const d = e.data;
    chrome.runtime.sendMessage({ type: 'QB_OPEN', url: d.url }, res => {
      if (!res || !res.ok) post({ type: 'QB_FORM_RES', id: d.id, ok: false, text: '表单没打开：' + ((res && res.text) || (chrome.runtime.lastError && chrome.runtime.lastError.message) || '扩展无响应'), notOpened: true });
    });
  });
  window.addEventListener('message', e => {
    if (e.source !== window || !e.data || e.data.type !== 'QB_STAGE_REQ') return;
    const d = e.data;
    chrome.runtime.sendMessage({ type: 'QB_STAGE', url: d.url, mode: d.mode, id: d.id }, res => {
      if (!res || !res.ok) post({ type: 'QB_FORM_RES', id: d.id, ok: false, text: '工单没打开：' + ((res && res.text) || (chrome.runtime.lastError && chrome.runtime.lastError.message) || '扩展无响应'), notOpened: true });
    });
  });
  chrome.runtime.onMessage.addListener(m => { if (m && m.type === 'QB_FORM_RES') post(m); });
  post({ type: 'QB_BRIDGE_READY', version: '1.4.0' });
})();
